var bg, bgImg
var bottomGround
var topGround
var plane, planeImg
var plane2, plane2Img
var plane3, plane3Img

var alien, alienImg, alienG
var alien2, alien2Img 
var alien3, alien3Img
var alien4, alien4Img
var alien5, alien5Img

var boss, bossImg
var bullet1, bullet2, bullet1Img, bullet2Img, bulletG, ultraBulletImg, ultraBullet, ultraBulletG

var score = 0;
var energy = 0;
var bullets = 20



// add damage per bullet
// make boss die after certain damage
// switch between plane2 and plane3
// make the game more fun



function preload(){
  bgImg = loadImage("assets/bg.jpg")

  planeImg = loadImage("assets/plane1.png")
  plane2Img = loadImage("assets/plane2.png")
  plane3Img = loadImage("assets/plane3.png")

  alienImg = loadImage("assets/alien1.png")
  alien2Img = loadImage("assets/alien2.png")
  alien3Img = loadImage("assets/alien3.png")
  alien4Img = loadImage("assets/alien4.png")
  alien5Img = loadImage("assets/alien5.png")
  ultraBulletImg = loadImage("assets/bullet2.png")
  

  bossImg = loadImage("assets/boss.png")

  bullet1Img = loadImage("assets/bullet.png")
  bullet2Img = loadImage("assets/bullet2.png")
}

function setup(){

const canvas = createCanvas(1200,650)
canvas.elt.addEventListener("contextmenu", (e) => e.preventDefault())

//background image
bg = createSprite(600,350,1,1);
bg.addImage(bgImg);
bg.scale = 0.45  

//creating top and bottom grounds
bottomGround = createSprite(200,390,800,20);
bottomGround.visible = false;

topGround = createSprite(200,10,800,20);
topGround.visible = false;
      
//creating plane     
plane = createSprite(150,200,20,50);
plane.addImage("plane",plane3Img);
plane.scale = 0.3
plane.rotation = -90

alienG = new Group()
bulletG = new Group();
ultraBulletG = new Group();


}

function draw() {
        
      //making the plane jump
      if(keyDown("space")) {
        plane.velocityY -= 3 ;
      }
      
      if(frameCount % 1000 == 0){
        boss = createSprite(1050, 300, 20, 20);
        boss.addImage("boss",bossImg);
        boss.scale = 1
        boss.velocityX = -0.5
        boss.rotation = 90
        boss.depth = alien.depth + 1

      }
      
      
      //creating alien
      if(frameCount % 100 == 0){
        randomN = Math.round(random(0,4))
        energy += 5
        bullets += 2
      
        if(randomN == 0){
          alien = createSprite(1050, random(50, 600), 20, 20);
          alien.addImage("alien",alienImg);
          alien.scale = 0.4
          alien.velocityX = -1.5
          alienG.add(alien)
          
        }

        if(randomN == 1){
          alien2 = createSprite(1050, random(50, 600), 20, 20);
          alien2.addImage("alien2",alien2Img);
          alien2.scale = 0.4 
          alien2.velocityX = -0.7
          alienG.add(alien2)
          
        }

        if(randomN == 2){
          alien3 = createSprite(1050, random(50, 600), 20, 20);
          alien3.addImage("alien3",alien3Img);
          alien3.scale = 0.4
          alien3.velocityX = -0.7
          alienG.add(alien3)
          
        }

        if(randomN == 3){
          alien4 = createSprite(1050, random(50, 600), 20, 20);
          alien4.addImage("alien4",alien4Img);
          alien4.scale = 0.4 
          alien4.velocityX = -0.7
          alienG.add(alien4)
          
        }

        if(randomN == 4){
          alien5 = createSprite(1050, random(50, 600), 20, 20);
          alien5.addImage("alien5",alien5Img);
          alien5.scale = 0.4 
          alien5.velocityX = -0.7
          alienG.add(alien5)
          
        }
        }
        
        for(var i=0;i<alienG.length;i++){     
             
         if(alienG[i].isTouching(bulletG)){
              alienG[i].destroy()
              bulletG.destroyEach()
              score += 5
              energy += 10
              } 
        }

        for(var i=0;i<alienG.length;i++){     
             
          if(alienG[i].isTouching(ultraBulletG)){
            alienG[i].destroy()
            ultraBulletG.destroyEach()
            score += 5
            energy += 10
          } 

         }

        //adding gravity  
        plane.velocityY = plane.velocityY + 1.5;
      
        drawSprites();
        textSize(25)
        text("Score: "+ score, 40, 50)
        text("Energy: "+ energy, 40, 85)
        text("Bullets "+ bullets, 40, 125)

      }

function mousePressed(){
  if(mouseButton == LEFT && bullets > 0){
    bullet1 = createSprite(plane.x + 30, plane.y, 20, 20);
    bullet1.addImage("bullet", bullet1Img)
    bullet1.scale = 0.4
    bullet1.velocityX = 20
    bulletG.add(bullet1)
    bullets -= 1
   
  }

  if(mouseButton == RIGHT && energy >= 50){
    ultraBullet = createSprite(plane.x + 30, plane.y, 20, 20);
    ultraBullet.addImage("Ultrabullet", ultraBulletImg)
    ultraBullet.scale = 0.8
    ultraBullet.velocityX = 10
    ultraBullet.rotation = 0
    ultraBulletG.add(ultraBullet)
    energy -= 50
  }
}


